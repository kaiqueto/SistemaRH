import { HttpInterceptorFn } from '@angular/common/http';
import { inject, Inject } from '@angular/core';
import { AuthService } from '../services/auth';

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const token = inject(AuthService).token();
  
  if (!token) return next(req);

  return next(req.clone({setHeaders:{Authorization: `Bearer ${token}`}}

  ));
};
